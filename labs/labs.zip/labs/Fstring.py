
X = Why_does

Y = This_work

print (f"{X} {Y}")
