print("""You wake up and look around. 
Your in a field with only lush green tree's darkened by the knight sky.""")
print("?:Where am I? Oww! my head.")
print("The moon becomes brighter and brighter. The light begins to bother you and you can't see")
print("Lunar:You there bask in the glory of Lunar the goddes of night what are you")
print("1.I'm a Boy 2. I'm a Girl 3. ...")
input (">")
if input == "a" :
    print("Lunar:Good for you, I meant your name what are you called.")
elif input == "b" :
    print("Lunar:You are a very... dense I meant your name.")
elif input == "c" :
    print("Lunar:You... did hear me correct, hello. Crap another silent type I thought kids were getting smarter oh whatever i'll call you a dissapointment ")
elif input != "1" or "2" or "3" :
    print("Lunar:If you don't give me a serious answer i'll kill you and spare us both some time.")
print("Lunar:If it's something ridiculous like steve, greg or Bob I will leave you here. ")
input (">")
input(name)
print(f"Lunar:so your name is {name}")
print("Lunar:So {name} let's get started and try not to die")
print(f"{name}:Ok ")