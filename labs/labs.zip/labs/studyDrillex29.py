people = 20
cats = 30
dogs = 15


if people < cats:
    print("Too many cats! the world is doomed!")

if people > cats:
    print ("Not many cats! The world is saved!")

if people < dogs :
    print("the world is drooled on")

if people > dogs :
    print("The world is dry")


dogs+=5

if people >= dogs:
    print("The amount of People are are greater or eqaul to the amount of dogs")

if people <=dogs :
     print("The amount of people are less than or equal to the amount of dogs")


if people == dogs:
    print("People are eqaul to dogs")
    