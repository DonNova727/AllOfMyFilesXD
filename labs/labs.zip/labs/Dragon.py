print("Ducktales is worse than digiimon frontier")
print("Powerpuff")
print ('''It started when an alien device did what it did
It stuck itself upon his wrist with secrets that it hid
Now he's got superpowers he's no ordinary kid
He's BEN 10
So if you see him you might be in for a big surprise
He'll turn into an alien before your very eyes
He's slimy, creepy, fast and strong
He's every shape and size
He's BEN 10
Armed with powers he's on the case
Fighting off evil from earth or space
He'll never stop till he makes them pay
Coz he's the baddest kid to ever save day
BEN 10
B-b-b-ben
B-b-b-ben
''')