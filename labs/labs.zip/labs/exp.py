from sys import argv
scypt,name, password=argv

if argv == name,password:
    name="Donovan"
    password="Don"
    print(f"Hello {name} you have succesfully logged in")




